package keeper

import (
	"swisstronik/x/swisstronik/types"
)

var _ types.QueryServer = Keeper{}
